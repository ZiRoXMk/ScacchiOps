/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.scacchi;





/**
 *
 * @author sammy
 */
public class Scacchi {

    public static void main(String[] args) {
        Scaccchiera miagui = new Scaccchiera();
        miagui.setVisible(true);
        while(true)
        {}
    }
}
